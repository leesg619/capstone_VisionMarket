export const USER_LOGIN = 'user_login'
export const USER_REGISTER = 'user_register'
export const USER_LOGOUT = 'user_logout'
export const USER_AUTH = 'user_auth'

export const ADMINPOST_SAVE = 'adminPost_save'
export const ADMINPOST_SEARCH = 'adminPost_search'