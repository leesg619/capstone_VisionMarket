/* eslint-disable import/no-anonymous-default-export */
import long from './ExampleJPG/1.png';
import flower from './ExampleJPG/2.png';

export default [
    {            
        productName: "롱스커트",
        imgSrc: long,
        productCount: "1",
        productPrice: "10000"
    },
    {
        productName: "꽃무늬원피스",
        imgSrc: flower,
        productCount: "1",
        productPrice: "35000"
    }
]