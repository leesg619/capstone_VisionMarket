export const USER_SERVER = '/api/users';
export const ADMIN_POST_SERVER = '/api/admin/posts';